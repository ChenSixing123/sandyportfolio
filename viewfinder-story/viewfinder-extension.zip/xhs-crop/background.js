// background.js — service worker
// 职责:
// 1. 点击插件图标时,向当前标签页注入/切换取景框
// 2. 接收 content script 的截图请求,调用 captureVisibleTab
// 3. 接收下载请求,调用 chrome.downloads

// 点击工具栏图标 → 注入 content script(若已注入则发消息切换显示)
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id) return;
  // 不能在 chrome:// 等页面注入
  if (!/^https?:|^file:/.test(tab.url || "")) return;

  try {
    // 先尝试发消息,如果 content script 已存在就切换
    await chrome.tabs.sendMessage(tab.id, { type: "XHS_TOGGLE" });
  } catch (e) {
    // 消息失败说明还没注入,注入之
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"],
    });
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "XHS_CAPTURE") {
    // 截取当前窗口可视区域,返回 dataURL(PNG, 物理像素)
    chrome.tabs.captureVisibleTab(
      sender.tab ? sender.tab.windowId : undefined,
      { format: "png" },
      (dataUrl) => {
        if (chrome.runtime.lastError) {
          sendResponse({ ok: false, error: chrome.runtime.lastError.message });
        } else {
          sendResponse({ ok: true, dataUrl });
        }
      }
    );
    return true; // 异步 sendResponse
  }

  if (msg.type === "XHS_DOWNLOAD") {
    chrome.downloads.download(
      {
        url: msg.dataUrl,
        filename: msg.filename || "xhs-crop.png",
        saveAs: false,
      },
      () => sendResponse({ ok: !chrome.runtime.lastError })
    );
    return true;
  }
});
