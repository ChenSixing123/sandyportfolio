// content.js — 取景框 overlay(Shadow DOM 隔离样式)
(() => {
  // 防止重复注入:如果已存在,监听消息即可
  if (window.__XHS_CROP_LOADED__) return;
  window.__XHS_CROP_LOADED__ = true;

  // ---------- 状态 ----------
  const RATIOS = {
    "3:4": 3 / 4,
    "1:1": 1,
    "4:3": 4 / 3,
  };
  let ratioKey = "3:4";
  let box = { x: 0, y: 0, w: 375, h: 500 }; // viewport 坐标(CSS px)
  let visible = false;

  // ---------- 页眉(品牌横幅)设置 ----------
  const BANNER_FRAC = 0.09; // 页眉高度 = 成品宽度的 9%
  let banner = { enabled: false, name: "", avatar: "" }; // avatar 为 dataURL
  chrome.storage.local.get("xhs_banner").then((d) => {
    if (d.xhs_banner) banner = { ...banner, ...d.xhs_banner };
    if (visible) { render(); updateBannerUI(); }
  });
  function saveBanner() {
    chrome.storage.local.set({ xhs_banner: banner });
  }

  // 有效比例:开启页眉时,取景框只框"内容区",
  // 内容区高度 = 成品高度 - 页眉高度,保证 内容+页眉 拼出来正好是所选比例
  function R() {
    const r = RATIOS[ratioKey];
    if (!banner.enabled) return r;
    // h_total = w/r, h_banner = BANNER_FRAC*w → h_content = w*(1/r - BANNER_FRAC)
    return 1 / (1 / r - BANNER_FRAC);
  }

  // ---------- Shadow DOM 挂载 ----------
  const host = document.createElement("div");
  host.id = "__xhs_crop_host__";
  host.style.cssText =
    "position:fixed;inset:0;z-index:2147483647;pointer-events:none;";
  const shadow = host.attachShadow({ mode: "open" });

  shadow.innerHTML = `
<style>
  :host { all: initial; }
  * { box-sizing: border-box; margin: 0; padding: 0;
      font-family: -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif; }

  .mask { position: fixed; background: rgba(15,18,25,.38); pointer-events: none; }

  .frame {
    position: fixed;
    border: 2px solid #ff2e4d;
    box-shadow: 0 0 0 1px rgba(255,255,255,.6);
    pointer-events: none;   /* 框内完全穿透:滚动/点击直达底下页面 */
    outline: none;
  }

  /* 四条边框条:唯一可拖拽移动的区域 */
  .edge {
    position: absolute; pointer-events: auto; cursor: move; outline: none;
  }
  .edge:focus { background: rgba(255,46,77,.25); }
  .edge.t { left: 0; right: 0; top: -6px;    height: 12px; }
  .edge.b { left: 0; right: 0; bottom: -6px; height: 12px; }
  .edge.l { top: 0; bottom: 0; left: -6px;   width: 12px; }
  .edge.r { top: 0; bottom: 0; right: -6px;  width: 12px; }

  .handle {
    position: absolute; width: 14px; height: 14px;
    background: #fff; border: 2px solid #ff2e4d; border-radius: 50%;
    pointer-events: auto;
  }
  .handle.nw { left: -8px;  top: -8px;    cursor: nwse-resize; }
  .handle.ne { right: -8px; top: -8px;    cursor: nesw-resize; }
  .handle.sw { left: -8px;  bottom: -8px; cursor: nesw-resize; }
  .handle.se { right: -8px; bottom: -8px; cursor: nwse-resize; }

  .size-tag {
    position: absolute; left: 50%; top: -34px; transform: translateX(-50%);
    background: #1c1f26; color: #fff; font-size: 12px; line-height: 1;
    padding: 6px 10px; border-radius: 6px; white-space: nowrap;
    pointer-events: none; font-variant-numeric: tabular-nums;
  }

  .toolbar {
    position: fixed; display: flex; gap: 8px; align-items: center;
    background: #1c1f26; padding: 8px 10px; border-radius: 10px;
    box-shadow: 0 4px 16px rgba(0,0,0,.3);
    pointer-events: auto;
  }
  .toolbar button {
    border: 0; border-radius: 6px; padding: 6px 12px; font-size: 13px;
    cursor: pointer; background: #2a2e38; color: #dfe3ea;
  }
  .toolbar button:hover { background: #363b47; }
  .toolbar button.ratio.active { background: #ff2e4d; color: #fff; }
  .toolbar button.shoot { background: #ff2e4d; color: #fff; font-weight: 600; }
  .toolbar button.shoot:hover { background: #e12945; }
  .toolbar button.gallery-btn { background: #2a2e38; color: #ffd166; font-weight: 600; }

  /* 图集浮层 */
  .gallery-card { max-width: 84vw; }
  .g-grid {
    display: flex; gap: 12px; flex-wrap: wrap; overflow-y: auto;
    max-height: 60vh; padding: 4px;
  }
  .g-item {
    width: 150px; display: flex; flex-direction: column; gap: 6px;
  }
  .g-item img {
    width: 100%; border: 1px solid #e5e7ec; border-radius: 6px; display: block;
  }
  .g-meta { font-size: 12px; color: #555b68; font-variant-numeric: tabular-nums; }
  .g-acts { display: flex; gap: 6px; }
  .g-acts button {
    flex: 1; border: 0; border-radius: 6px; padding: 5px 0; font-size: 12px;
    cursor: pointer; background: #eef0f4; color: #333;
  }
  .g-acts .g-del { color: #c0392b; }

  /* 设置面板 */
  .settings-card { max-width: 380px; width: 380px; gap: 16px; }
  .s-title { font-size: 15px; font-weight: 600; color: #1c1f26; }
  .s-row { display: flex; align-items: center; gap: 12px; }
  .s-row label { font-size: 13px; color: #555b68; min-width: 56px; }
  .s-row input[type="text"] {
    flex: 1; border: 1px solid #d8dbe2; border-radius: 8px;
    padding: 8px 10px; font-size: 14px; outline: none;
  }
  .s-row input[type="text"]:focus { border-color: #ff2e4d; }
  .s-ava-preview {
    width: 44px; height: 44px; border-radius: 50%; object-fit: cover;
    border: 1px solid #e5e7ec; background: #f4f5f8;
  }
  .s-upload-btn {
    border: 1px dashed #c3c8d2; background: #fafbfc; color: #555b68;
    border-radius: 8px; padding: 8px 14px; font-size: 13px; cursor: pointer;
  }
  .s-upload-btn:hover { border-color: #ff2e4d; color: #ff2e4d; }
  .s-toggle { display: flex; align-items: center; gap: 8px; cursor: pointer;
    font-size: 14px; color: #1c1f26; }
  .s-toggle input { width: 18px; height: 18px; accent-color: #ff2e4d; cursor: pointer; }
  .s-hint { font-size: 12px; color: #8b91a0; line-height: 1.5; }
  .s-banner-demo {
    display: flex; align-items: center; gap: 10px; background: #fff;
    border: 1px solid #e5e7ec; border-radius: 8px; padding: 10px 12px;
  }
  .s-banner-demo img { width: 32px; height: 32px; border-radius: 50%; object-fit: cover; }
  .s-banner-demo span { font-size: 14px; color: #333; font-weight: 500; }
  .toolbar .close { background: transparent; color: #8b91a0; padding: 6px 8px; }
  .toolbar .close:hover { color: #fff; background: #363b47; }

  .hint {
    position: fixed; left: 50%; bottom: 18px; transform: translateX(-50%);
    background: rgba(28,31,38,.92); color: #aab0bd; font-size: 12px;
    padding: 6px 14px; border-radius: 999px; pointer-events: none;
  }

  /* 预览浮层 */
  .preview-wrap {
    position: fixed; inset: 0; background: rgba(10,12,16,.72);
    display: flex; align-items: center; justify-content: center;
    pointer-events: auto;
  }
  .preview-card {
    background: #fff; border-radius: 14px; padding: 16px;
    max-width: 78vw; max-height: 86vh; display: flex; flex-direction: column; gap: 12px;
  }
  .preview-card img {
    max-width: 100%; max-height: 62vh; object-fit: contain;
    border: 1px solid #e5e7ec; border-radius: 8px; display: block;
  }
  .preview-meta { font-size: 13px; color: #555b68; }
  .preview-actions { display: flex; gap: 10px; justify-content: flex-end; }
  .preview-actions button {
    border: 0; border-radius: 8px; padding: 9px 16px; font-size: 14px; cursor: pointer;
  }
  .btn-primary { background: #ff2e4d; color: #fff; font-weight: 600; }
  .btn-ghost { background: #eef0f4; color: #333; }
  .toast {
    position: fixed; left: 50%; top: 24px; transform: translateX(-50%);
    background: #1c1f26; color: #fff; padding: 8px 16px; border-radius: 8px;
    font-size: 13px; pointer-events: none; opacity: 0; transition: opacity .2s;
  }
  .toast.show { opacity: 1; }
  .hidden { display: none !important; }
</style>
<div class="mask" data-m="t"></div>
<div class="mask" data-m="b"></div>
<div class="mask" data-m="l"></div>
<div class="mask" data-m="r"></div>
<div class="frame">
  <div class="size-tag"></div>
  <div class="edge t" tabindex="0"></div>
  <div class="edge b" tabindex="0"></div>
  <div class="edge l" tabindex="0"></div>
  <div class="edge r" tabindex="0"></div>
  <div class="handle nw" data-h="nw"></div>
  <div class="handle ne" data-h="ne"></div>
  <div class="handle sw" data-h="sw"></div>
  <div class="handle se" data-h="se"></div>
</div>
<div class="toolbar">
  <button class="ratio active" data-r="3:4">3:4</button>
  <button class="ratio" data-r="1:1">1:1</button>
  <button class="ratio" data-r="4:3">4:3</button>
  <button class="shoot">📷 截图</button>
  <button class="scroll-step" title="页面向下滚动一个框的高度">⬇ 滚一框</button>
  <button class="gallery-btn hidden">🖼 <span class="count">0</span></button>
  <button class="settings-btn" title="页眉设置">⚙</button>
  <button class="close" title="关闭 (Esc)">✕</button>
</div>
<div class="hint">框内可直接滚动/操作文档 · 拖边框移动 · 拖四角缩放 · 点边框后方向键微调 · Esc 关闭</div>
<div class="toast"></div>
`;

  const $ = (sel) => shadow.querySelector(sel);
  const $$ = (sel) => shadow.querySelectorAll(sel);
  const frame = $(".frame");
  const sizeTag = $(".size-tag");
  const toolbar = $(".toolbar");
  const toast = $(".toast");
  const masks = {
    t: $('[data-m="t"]'),
    b: $('[data-m="b"]'),
    l: $('[data-m="l"]'),
    r: $('[data-m="r"]'),
  };

  // ---------- 渲染 ----------
  function clampBox() {
    const vw = window.innerWidth, vh = window.innerHeight;
    box.w = Math.max(60, Math.min(box.w, vw));
    box.h = box.w / R();
    if (box.h > vh) { box.h = vh; box.w = box.h * R(); }
    box.x = Math.max(0, Math.min(box.x, vw - box.w));
    box.y = Math.max(0, Math.min(box.y, vh - box.h));
  }

  function render() {
    clampBox();
    const { x, y, w, h } = box;
    frame.style.cssText += `;left:${x}px;top:${y}px;width:${w}px;height:${h}px;`;
    masks.t.style.cssText += `;left:0;top:0;width:100vw;height:${y}px;`;
    masks.b.style.cssText += `;left:0;top:${y + h}px;width:100vw;height:calc(100vh - ${y + h}px);`;
    masks.l.style.cssText += `;left:0;top:${y}px;width:${x}px;height:${h}px;`;
    masks.r.style.cssText += `;left:${x + w}px;top:${y}px;width:calc(100vw - ${x + w}px);height:${h}px;`;

    const dpr = window.devicePixelRatio || 1;
    const outW = Math.round(box.w * dpr);
    const outH = Math.round(
      banner.enabled ? box.h * dpr + outW * BANNER_FRAC : box.h * dpr
    );
    sizeTag.textContent =
      `${outW} × ${outH} px` + (banner.enabled ? "(含页眉)" : "");

    // 工具条:优先放在框下方,放不下则放框上方
    const tbTop = y + h + 12 + 46 < window.innerHeight ? y + h + 12 : Math.max(8, y - 58);
    toolbar.style.left = `${Math.max(8, x)}px`;
    toolbar.style.top = `${tbTop}px`;
  }

  function centerBox() {
    const vw = window.innerWidth, vh = window.innerHeight;
    const r = R();
    let h = Math.min(vh * 0.7, 560);
    let w = h * r;
    if (w > vw * 0.9) { w = vw * 0.9; h = w / r; }
    box = { x: (vw - w) / 2, y: (vh - h) / 2, w, h };
  }

  // ---------- 显示/隐藏 ----------
  function show() {
    if (!host.isConnected) document.documentElement.appendChild(host);
    host.style.display = "";
    if (box.x === 0 && box.y === 0) centerBox();
    visible = true;
    render();
    shadow.querySelector(".edge.t").focus();
  }
  function hide() {
    host.style.display = "none";
    visible = false;
  }
  function toggle() { visible ? hide() : show(); }

  // ---------- 拖拽移动(只在四条边框条上生效,框内穿透) ----------
  let drag = null;
  $$(".edge").forEach((edge) => {
    edge.addEventListener("pointerdown", (e) => {
      drag = { mode: "move", sx: e.clientX, sy: e.clientY, ...box };
      edge.setPointerCapture(e.pointerId);
      edge.focus();
      e.preventDefault();
    });
    edge.addEventListener("pointermove", onDragMove);
    edge.addEventListener("pointerup", () => (drag = null));
    edge.addEventListener("pointercancel", () => (drag = null));
  });

  // ---------- 四角等比缩放 ----------
  $$(".handle").forEach((h) => {
    h.addEventListener("pointerdown", (e) => {
      drag = { mode: "resize", corner: h.dataset.h, sx: e.clientX, sy: e.clientY, ...box };
      h.setPointerCapture(e.pointerId);
      e.stopPropagation();
      e.preventDefault();
    });
    h.addEventListener("pointermove", onDragMove);
    h.addEventListener("pointerup", () => (drag = null));
    h.addEventListener("pointercancel", () => (drag = null));
  });

  function onDragMove(e) {
    if (!drag) return;
    const dx = e.clientX - drag.sx;
    const dy = e.clientY - drag.sy;
    const r = R();

    if (drag.mode === "move") {
      box.x = drag.x + dx;
      box.y = drag.y + dy;
    } else {
      // 等比缩放:以对角为锚点,取水平位移换算
      const c = drag.corner;
      let w = drag.w + (c.includes("e") ? dx : -dx);
      w = Math.max(60, w);
      const hgt = w / r;
      box.w = w;
      box.h = hgt;
      box.x = c.includes("w") ? drag.x + drag.w - w : drag.x;
      box.y = c.includes("n") ? drag.y + drag.h - hgt : drag.y;
    }
    render();
  }

  // ---------- 键盘微调(先点一下任意边框条获得焦点,再用方向键) ----------
  $$(".edge").forEach((edge) => {
    edge.addEventListener("keydown", (e) => {
      const step = e.shiftKey ? 10 : 1;
      let used = true;
      switch (e.key) {
        case "ArrowUp":    box.y -= step; break;
        case "ArrowDown":  box.y += step; break;
        case "ArrowLeft":  box.x -= step; break;
        case "ArrowRight": box.x += step; break;
        default: used = false;
      }
      if (used) { e.preventDefault(); e.stopPropagation(); render(); }
    });
  });

  // Esc 全局关闭(不抢占页面其他按键)
  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && visible) hide();
  });

  // ---------- 比例切换(以中心为基准) ----------
  $$(".ratio").forEach((btn) => {
    btn.addEventListener("click", () => {
      $$(".ratio").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      const cx = box.x + box.w / 2;
      const cy = box.y + box.h / 2;
      ratioKey = btn.dataset.r;
      const r = R();
      // 保持面积近似不变
      const area = box.w * box.h;
      box.w = Math.sqrt(area * r);
      box.h = box.w / r;
      box.x = cx - box.w / 2;
      box.y = cy - box.h / 2;
      render();
      shadow.querySelector(".edge.t").focus();
    });
  });

  // ---------- 关闭 ----------
  $(".close").addEventListener("click", hide);

  // ---------- 截图(队列模式) ----------
  const shots = []; // { dataUrl, w, h }
  const galleryBtn = $(".gallery-btn");
  const countEl = $(".count");

  function showToast(text) {
    toast.textContent = text;
    toast.classList.add("show");
    setTimeout(() => toast.classList.remove("show"), 1800);
  }

  function updateCount() {
    countEl.textContent = String(shots.length);
    galleryBtn.classList.toggle("hidden", shots.length === 0);
  }

  $(".shoot").addEventListener("click", async () => {
    // 记录当前框(CSS px)并换算物理像素
    const dpr = window.devicePixelRatio || 1;
    const crop = {
      x: Math.round(box.x * dpr),
      y: Math.round(box.y * dpr),
      w: Math.round(box.w * dpr),
      h: Math.round(box.h * dpr),
    };

    // 截图前隐藏 overlay,避免截到自己
    host.style.display = "none";
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));

    let resp;
    try {
      resp = await chrome.runtime.sendMessage({ type: "XHS_CAPTURE" });
    } catch (err) {
      resp = { ok: false, error: String(err) };
    }
    host.style.display = "";

    if (!resp || !resp.ok) {
      showToast("截图失败:" + (resp?.error || "未知错误"));
      return;
    }

    const img = new Image();
    img.onload = async () => {
      // 按截图实际尺寸与 viewport 比例校正,高分屏/缩放不偏移
      const scaleX = img.width / (window.innerWidth * dpr);
      const scaleY = img.height / (window.innerHeight * dpr);
      const contentW = Math.round(crop.w * scaleX);
      const contentH = Math.round(crop.h * scaleY);
      const bannerH = banner.enabled ? Math.round(contentW * BANNER_FRAC) : 0;

      const canvas = document.createElement("canvas");
      canvas.width = contentW;
      canvas.height = contentH + bannerH;
      const ctx = canvas.getContext("2d");

      // 页眉:白底 + 圆形头像 + 昵称
      if (bannerH > 0) {
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, contentW, bannerH);

        const pad = bannerH * 0.42;      // 左边距
        const avaD = bannerH * 0.62;     // 头像直径
        const avaX = pad, avaY = (bannerH - avaD) / 2;
        let textX = pad;

        if (banner.avatar) {
          try {
            const ava = await loadImage(banner.avatar);
            ctx.save();
            ctx.beginPath();
            ctx.arc(avaX + avaD / 2, avaY + avaD / 2, avaD / 2, 0, Math.PI * 2);
            ctx.clip();
            // cover 式绘制,头像非正方形也不变形
            const s = Math.max(avaD / ava.width, avaD / ava.height);
            const dw = ava.width * s, dh = ava.height * s;
            ctx.drawImage(ava, avaX + (avaD - dw) / 2, avaY + (avaD - dh) / 2, dw, dh);
            ctx.restore();
            textX = avaX + avaD + bannerH * 0.28;
          } catch { /* 头像加载失败则只画文字 */ }
        }
        if (banner.name) {
          ctx.fillStyle = "#333333";
          ctx.font = `500 ${Math.round(bannerH * 0.34)}px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif`;
          ctx.textBaseline = "middle";
          ctx.fillText(banner.name, textX, bannerH / 2 + bannerH * 0.02);
        }
      }

      // 内容区
      ctx.drawImage(
        img,
        crop.x * scaleX, crop.y * scaleY, crop.w * scaleX, crop.h * scaleY,
        0, bannerH, contentW, contentH
      );
      shots.push({
        dataUrl: canvas.toDataURL("image/png"),
        w: canvas.width,
        h: canvas.height,
      });
      updateCount();
      showToast(`已截第 ${shots.length} 张(${canvas.width}×${canvas.height})`);
    };
    img.src = resp.dataUrl;
  });

  function loadImage(src) {
    return new Promise((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = rej;
      i.src = src;
    });
  }

  // ---------- 滚一框:找到框中心下方的可滚动容器,精确滚动一个框高 ----------
  function findScrollable(startEl) {
    let el = startEl;
    while (el && el !== document.body && el !== document.documentElement) {
      const style = getComputedStyle(el);
      const canScroll =
        el.scrollHeight > el.clientHeight + 1 &&
        /(auto|scroll|overlay)/.test(style.overflowY);
      if (canScroll) return el;
      el = el.parentElement;
    }
    return document.scrollingElement || document.documentElement;
  }

  $(".scroll-step").addEventListener("click", () => {
    // 取框中心点下的元素(overlay 自身 pointer-events:none,不会挡住)
    const cx = box.x + box.w / 2;
    const cy = box.y + box.h / 2;
    const target = document.elementFromPoint(cx, cy);
    const scroller = findScrollable(target);
    const before = scroller.scrollTop;
    scroller.scrollBy({ top: box.h, behavior: "instant" });
    if (Math.abs(scroller.scrollTop - before) < 1) {
      // 该容器滚不动,回退到窗口滚动
      window.scrollBy({ top: box.h, behavior: "instant" });
    }
  });

  // ---------- 图集浮层(点 🖼 N 打开) ----------
  galleryBtn.addEventListener("click", openGallery);

  function batchFilename(i) {
    const ts = new Date().toISOString().slice(0, 10);
    const num = String(i + 1).padStart(2, "0");
    return `xhs-${ratioKey.replace(":", "x")}-${ts}-${num}.png`;
  }

  function openGallery() {
    const wrap = document.createElement("div");
    wrap.className = "preview-wrap";
    const items = shots
      .map(
        (s, i) => `
        <div class="g-item" data-i="${i}">
          <img src="${s.dataUrl}" alt="第${i + 1}张">
          <div class="g-meta">${String(i + 1).padStart(2, "0")} · ${s.w}×${s.h}</div>
          <div class="g-acts">
            <button class="g-copy" data-i="${i}">复制</button>
            <button class="g-del" data-i="${i}">删除</button>
          </div>
        </div>`
      )
      .join("");
    wrap.innerHTML = `
      <div class="preview-card gallery-card">
        <div class="g-grid">${items}</div>
        <div class="preview-actions">
          <button class="btn-ghost act-clear">清空全部</button>
          <button class="btn-primary act-download-all">下载全部 ${shots.length} 张</button>
          <button class="btn-ghost act-close">关闭</button>
        </div>
      </div>`;
    shadow.appendChild(wrap);

    wrap.addEventListener("click", async (e) => {
      const t = e.target;
      if (t === wrap || t.classList.contains("act-close")) {
        wrap.remove();
        return;
      }
      if (t.classList.contains("g-copy")) {
        const s = shots[+t.dataset.i];
        try {
          const blob = await (await fetch(s.dataUrl)).blob();
          await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
          showToast("已复制到剪贴板");
        } catch {
          showToast("复制失败,请用下载");
        }
        return;
      }
      if (t.classList.contains("g-del")) {
        shots.splice(+t.dataset.i, 1);
        updateCount();
        wrap.remove();
        if (shots.length) openGallery();
        return;
      }
      if (t.classList.contains("act-clear")) {
        shots.length = 0;
        updateCount();
        wrap.remove();
        showToast("已清空");
        return;
      }
      if (t.classList.contains("act-download-all")) {
        for (let i = 0; i < shots.length; i++) {
          await chrome.runtime.sendMessage({
            type: "XHS_DOWNLOAD",
            dataUrl: shots[i].dataUrl,
            filename: batchFilename(i),
          });
        }
        showToast(`已开始下载 ${shots.length} 张(自动编号)`);
        return;
      }
    });
  }

  // ---------- 页眉设置面板 ----------
  function updateBannerUI() { render(); }

  $(".settings-btn").addEventListener("click", () => {
    const wrap = document.createElement("div");
    wrap.className = "preview-wrap";
    wrap.innerHTML = `
      <div class="preview-card settings-card">
        <div class="s-title">页眉设置</div>
        <label class="s-toggle">
          <input type="checkbox" class="s-enable" ${banner.enabled ? "checked" : ""}>
          在每张截图顶部加上页眉
        </label>
        <div class="s-row">
          <label>头像</label>
          <img class="s-ava-preview" src="${banner.avatar || ""}" alt="">
          <button class="s-upload-btn">上传图片</button>
          <input type="file" class="s-file" accept="image/*" style="display:none">
        </div>
        <div class="s-row">
          <label>昵称</label>
          <input type="text" class="s-name" placeholder="例如:Sandy记事本"
            value="${banner.name.replace(/"/g, "&quot;")}">
        </div>
        <div class="s-banner-demo">
          <img class="d-ava" src="${banner.avatar || ""}" alt="">
          <span class="d-name">${banner.name || "昵称预览"}</span>
        </div>
        <div class="s-hint">开启后取景框会自动变矮一点,页眉拼上去之后,成品仍是标准的所选比例(如 3:4)。设置保存在本地,一次设置长期生效。</div>
        <div class="preview-actions">
          <button class="btn-primary act-save">保存</button>
          <button class="btn-ghost act-close">取消</button>
        </div>
      </div>`;
    shadow.appendChild(wrap);

    const fileInput = wrap.querySelector(".s-file");
    const avaPreview = wrap.querySelector(".s-ava-preview");
    const demoAva = wrap.querySelector(".d-ava");
    const demoName = wrap.querySelector(".d-name");
    let draft = { ...banner };

    wrap.querySelector(".s-upload-btn").addEventListener("click", () => fileInput.click());
    fileInput.addEventListener("change", () => {
      const f = fileInput.files[0];
      if (!f) return;
      const reader = new FileReader();
      reader.onload = () => {
        // 压缩到 128×128,避免 storage 存大图
        const tmp = new Image();
        tmp.onload = () => {
          const c = document.createElement("canvas");
          c.width = c.height = 128;
          const cx = c.getContext("2d");
          const s = Math.max(128 / tmp.width, 128 / tmp.height);
          const dw = tmp.width * s, dh = tmp.height * s;
          cx.drawImage(tmp, (128 - dw) / 2, (128 - dh) / 2, dw, dh);
          draft.avatar = c.toDataURL("image/png");
          avaPreview.src = draft.avatar;
          demoAva.src = draft.avatar;
        };
        tmp.src = reader.result;
      };
      reader.readAsDataURL(f);
    });

    wrap.querySelector(".s-name").addEventListener("input", (e) => {
      draft.name = e.target.value;
      demoName.textContent = draft.name || "昵称预览";
    });
    wrap.querySelector(".s-enable").addEventListener("change", (e) => {
      draft.enabled = e.target.checked;
    });

    wrap.querySelector(".act-save").addEventListener("click", () => {
      banner = draft;
      saveBanner();
      updateBannerUI();
      wrap.remove();
      showToast(banner.enabled ? "页眉已开启" : "页眉已关闭");
    });
    wrap.querySelector(".act-close").addEventListener("click", () => wrap.remove());
    wrap.addEventListener("click", (e) => { if (e.target === wrap) wrap.remove(); });
  });

  // ---------- 消息与窗口事件 ----------
  chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
    if (msg.type === "XHS_TOGGLE") {
      toggle();
      sendResponse({ ok: true });
    }
  });
  window.addEventListener("resize", () => visible && render());

  // 首次注入即显示
  show();
})();
